import React from 'react';

function Home() {
  return (
    <div className="h-screen flex items-center justify-center bg-gray-900 text-white text-2xl">
      Bienvenido a SOPRIM — Powered by Tailwind
    </div>
  );
}

export default Home;